// Shared by the content scripts, the popup and the receipt page.

// The studio behind Music Focus, shown on share cards and in X post text.
const STUDIO = { name: 'Nikola Tesla Studio', handle: '@NikolaTesla_eth' };

// Stats are stored per week (Monday to Sunday) under "week:YYYY-MM-DD" of the Monday.
function weekStart(date = new Date()) {
  const d = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  d.setDate(d.getDate() - ((d.getDay() + 6) % 7));
  return d;
}

function weekKey(date = new Date()) {
  const d = weekStart(date);
  const pad = (n) => String(n).padStart(2, '0');
  return `week:${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function emptyWeek() {
  return { seconds: 0, tracks: {}, dodged: 0, shortsSkipped: 0, shortsWatched: 0 };
}

// A track counts as "played" once it has had 30 seconds of listening.
function summarize(week) {
  const tracks = Object.entries(week.tracks)
    .map(([id, t]) => ({ id, ...t }))
    .filter((t) => t.s >= 30)
    .sort((a, b) => b.s - a.s);

  const byArtist = {};
  for (const t of tracks) if (t.a) byArtist[t.a] = (byArtist[t.a] || 0) + t.s;
  const topArtist = Object.entries(byArtist).sort((a, b) => b[1] - a[1])[0]?.[0] || '';

  return {
    seconds: week.seconds,
    songs: tracks.length,
    top: tracks.slice(0, 5),
    topArtist,
    dodged: week.dodged + week.shortsSkipped,
    shortsWatched: week.shortsWatched,
  };
}

function hoursMinutes(seconds) {
  const m = Math.floor(seconds / 60);
  return m >= 60 ? `${Math.floor(m / 60)}h ${m % 60}m` : `${m}m`;
}

// Music Focus Pro: a one-time purchase, sold through Lemon Squeezy and unlocked with a
// license key. While productId is null, Pro is switched off and every feature is free.
// build.mjs adds the Lemon Squeezy host permission only once productId is set.
const PRO = {
  productId: null, // Lemon Squeezy product ID (a number)
  checkoutUrl: '', // Lemon Squeezy checkout link for that product
  price: '$4.99',
  trialMinutes: 10,
};

// Whether Pro features (Classic mode and Brick) can be used right now.
function proActive(s, now = Date.now()) {
  return !PRO.productId || s.pro === true || (s.trialUntil || 0) > now;
}

// Callback-based storage wrapped in promises, which works the same in Chrome, Edge and Firefox.
function storageGet(keys) {
  return new Promise((resolve) => chrome.storage.local.get(keys, resolve));
}

function storageSet(items) {
  return new Promise((resolve) => chrome.storage.local.set(items, resolve));
}
