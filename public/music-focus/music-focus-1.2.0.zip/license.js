// Activates, re-checks and removes Music Focus Pro license keys using Lemon Squeezy's
// public license API. Only the key and a device label ("Music Focus on Chrome (Mac)")
// are sent, and only to Lemon Squeezy, and only when the user acts or a weekly re-check runs.

const LICENSE_API = 'https://api.lemonsqueezy.com/v1/licenses';
const RECHECK_MS = 7 * 24 * 60 * 60 * 1000;

async function licenseCall(action, params) {
  const res = await fetch(`${LICENSE_API}/${action}`, {
    method: 'POST',
    headers: { Accept: 'application/json', 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams(params),
  });
  const data = await res.json().catch(() => ({}));
  return { ok: res.ok, data };
}

async function activateLicense(rawKey) {
  const key = rawKey.trim();
  if (!key) throw new Error('Paste your license key first.');
  let result;
  try {
    result = await licenseCall('activate', { license_key: key, instance_name: deviceLabel() });
  } catch {
    throw new Error("Couldn't reach the license server. Check your connection and try again.");
  }
  const { ok, data } = result;
  if (!ok || !data.activated) {
    const error = String(data.error || '');
    if (/not found/i.test(error)) throw new Error("That key wasn't found. Check that you copied all of it.");
    if (/limit/i.test(error)) throw new Error('This key is already active on its maximum number of browsers. Remove it from one first.');
    throw new Error(error || "That key couldn't be activated.");
  }
  // Any Lemon Squeezy key would activate; only keys for this product unlock Pro.
  if (String(data.meta?.product_id) !== String(PRO.productId)) {
    await licenseCall('deactivate', { license_key: key, instance_id: data.instance?.id }).catch(() => {});
    throw new Error('That key is for a different product.');
  }
  await storageSet({ pro: true, license: { key, instanceId: data.instance.id, checkedAt: Date.now() } });
}

// Once a week, confirm the key is still good (refunds disable it). Offline keeps Pro.
async function recheckLicense() {
  const { license } = await storageGet({ license: null });
  if (!license || Date.now() - license.checkedAt < RECHECK_MS) return;
  try {
    const { data } = await licenseCall('validate', { license_key: license.key, instance_id: license.instanceId });
    if (data.valid) await storageSet({ license: { ...license, checkedAt: Date.now() } });
    else if (data.valid === false) await storageSet({ pro: false, license: null });
  } catch {
    // No connection: try again next time the popup opens.
  }
}

// Frees this browser's activation so the key can be used elsewhere.
async function removeLicense() {
  const { license } = await storageGet({ license: null });
  if (license) await licenseCall('deactivate', { license_key: license.key, instance_id: license.instanceId }).catch(() => {});
  await storageSet({ pro: false, license: null });
}

function deviceLabel() {
  const ua = navigator.userAgent;
  const browser = /Edg\//.test(ua) ? 'Edge' : /Firefox\//.test(ua) ? 'Firefox' : 'Chrome';
  const os = /Mac/.test(ua) ? 'Mac' : /Win/.test(ua) ? 'Windows' : /Linux/.test(ua) ? 'Linux' : 'device';
  return `Music Focus on ${browser} (${os})`;
}
