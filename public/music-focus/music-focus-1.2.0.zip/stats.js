// Weekly listening stats for the Focus Receipt. Everything stays in
// chrome.storage.local on this device; nothing is sent anywhere.
//
// Counted: seconds of music actually playing (ads excluded), per track; videos,
// Shorts and recommendations Music mode hid ("rabbit holes dodged"); and Shorts
// opened while Music mode was off, so "Shorts watched: 0" is only ever true.

const stats = {
  pending: null, // deltas not yet written to storage
  meta: {}, // video id -> { t: title, a: artist }
  lastTime: null,
  lastShort: null,
  seen: new WeakSet(),
};

const DODGE_SELECTOR = [
  '#related ytd-compact-video-renderer',
  '#related yt-lockup-view-model',
  'ytd-browse[page-subtype="home"] ytd-rich-item-renderer',
  'ytd-reel-shelf-renderer',
  'ytd-rich-shelf-renderer[is-shorts]',
  'grid-shelf-view-model',
  '.ytp-ce-element',
].join(',');

function pendingWeek() {
  return (stats.pending ??= { seconds: 0, tracks: {}, dodged: 0, shortsSkipped: 0, shortsWatched: 0 });
}

function noteTrack(id, title, artist) {
  stats.meta[id] = { t: title, a: artist };
}

function resetListening() {
  stats.lastTime = null;
}

// Called on every timeupdate (~4x a second); adds real playback time only.
function trackListening(video, id) {
  const now = video.currentTime;
  const last = stats.lastTime;
  stats.lastTime = now;
  if (!enabled || !id || last === null || video.paused) return;
  if (document.querySelector('#movie_player')?.classList.contains('ad-showing')) return;
  const delta = now - last;
  if (delta <= 0 || delta > 2) return; // seeks and jumps aren't listening
  const p = pendingWeek();
  p.seconds += delta;
  p.tracks[id] = (p.tracks[id] || 0) + delta;
}

function noteShortSkipped() {
  pendingWeek().shortsSkipped++;
}

function noteShortsVisit() {
  if (enabled) return;
  const m = location.pathname.match(/^\/shorts\/([\w-]+)/);
  if (m && m[1] !== stats.lastShort) {
    stats.lastShort = m[1];
    pendingWeek().shortsWatched++;
  }
}

function countDodged() {
  if (!enabled || document.hidden) return;
  let n = 0;
  for (const node of document.querySelectorAll(DODGE_SELECTOR)) {
    if (stats.seen.has(node)) continue;
    stats.seen.add(node);
    n++;
  }
  if (n) pendingWeek().dodged += n;
}

async function flushStats() {
  const p = stats.pending;
  if (!p) return;
  stats.pending = null;
  try {
    const key = weekKey();
    const week = (await storageGet(key))[key] || emptyWeek();
    week.seconds += p.seconds;
    week.dodged += p.dodged;
    week.shortsSkipped += p.shortsSkipped;
    week.shortsWatched += p.shortsWatched;
    for (const [id, s] of Object.entries(p.tracks)) {
      const t = (week.tracks[id] ??= { t: '', a: '', s: 0 });
      t.s += s;
      if (stats.meta[id]) Object.assign(t, stats.meta[id]);
    }
    await storageSet({ [key]: week });
  } catch {
    // The extension was reloaded or updated under this tab; this tab's stats are lost.
  }
}

setInterval(countDodged, 5000);
setInterval(flushStats, 15000);
document.addEventListener('visibilitychange', () => document.hidden && flushStats());
addEventListener('pagehide', flushStats);
