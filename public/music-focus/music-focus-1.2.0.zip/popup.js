const toggle = document.getElementById('toggle');
const status = document.getElementById('status');
const skins = document.querySelectorAll('input[name="skin"]');
const $ = (id) => document.getElementById(id);

let state = { pro: false, trialUntil: 0, skin: 'modern' };

function renderEnabled(enabled) {
  toggle.checked = enabled;
  status.textContent = enabled ? 'On' : 'Off: regular YouTube';
}

function renderSkin() {
  for (const input of skins) input.checked = input.value === (state.skin === 'ipod' && proActive(state) ? 'ipod' : 'modern');
}

// The Pro panel only exists once a Lemon Squeezy product is configured (PRO in shared.js).
function renderPro() {
  if (!PRO.productId) return;
  $('pro').hidden = false;
  $('pro-badge').hidden = state.pro;
  $('pro-upsell').hidden = state.pro;
  $('pro-owned').hidden = !state.pro;
  const left = Math.ceil(((state.trialUntil || 0) - Date.now()) / 60000);
  $('pro-pitch').textContent =
    left > 0
      ? `Trial running: ${left} min left of Classic mode and Brick.`
      : `The click-wheel Classic player, Brick, and every future skin and game. ${PRO.price}, once.`;
  $('pro-trial').hidden = left > 0 || state.trialUntil > 0; // one trial per browser
  $('pro-buy').textContent = `Get Pro · ${PRO.price}`;
  $('pro-buy').href = PRO.checkoutUrl;
}

function message(text, isError = false) {
  $('pro-msg').textContent = text;
  $('pro-msg').classList.toggle('error', isError);
}

const key = weekKey();
chrome.storage.local.get({ enabled: true, skin: 'modern', pro: false, trialUntil: 0, [key]: emptyWeek() }, (s) => {
  renderEnabled(s.enabled);
  state = { pro: s.pro, trialUntil: s.trialUntil, skin: s.skin };
  renderSkin();
  renderPro();

  const week = summarize(s[key]);
  $('st-time').textContent = hoursMinutes(week.seconds);
  $('st-songs').textContent = week.songs.toLocaleString();
  $('st-dodged').textContent = week.dodged.toLocaleString();
});

if (PRO.productId) recheckLicense();

chrome.storage.onChanged.addListener((changes) => {
  for (const k of ['pro', 'trialUntil', 'skin']) if (changes[k]) state[k] = changes[k].newValue;
  renderSkin();
  renderPro();
});

toggle.addEventListener('change', () => {
  chrome.storage.local.set({ enabled: toggle.checked });
  renderEnabled(toggle.checked);
});

for (const input of skins) {
  input.addEventListener('change', () => {
    if (input.value === 'ipod' && !proActive(state)) {
      renderSkin(); // stay on Modern and point at the upgrade
      message('Classic mode is part of Pro. Try it free for 10 minutes, or get Pro.');
      $('pro').scrollIntoView({ behavior: 'smooth' });
      return;
    }
    chrome.storage.local.set({ skin: input.value });
  });
}

$('pro-trial').addEventListener('click', () => {
  chrome.storage.local.set({ trialUntil: Date.now() + PRO.trialMinutes * 60000, skin: 'ipod' });
  message('Trial started. Open a song on YouTube and press MENU on the wheel for Brick.');
});

$('pro-activate').addEventListener('click', async () => {
  const button = $('pro-activate');
  button.disabled = true;
  message('Activating…');
  try {
    await activateLicense($('pro-key').value);
    message('');
  } catch (error) {
    message(error.message, true);
  } finally {
    button.disabled = false;
  }
});

$('pro-remove').addEventListener('click', async () => {
  await removeLicense();
  await storageSet({ skin: 'modern' });
});

$('receipt').addEventListener('click', () => {
  chrome.tabs.create({ url: 'receipt.html' });
});
