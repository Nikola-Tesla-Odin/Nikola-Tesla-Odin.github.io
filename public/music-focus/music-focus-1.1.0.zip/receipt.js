// Draws the weekly Focus Receipt onto a 1080x1350 canvas (4:5, fits X's
// timeline) and offers copy / download / post. No images are fetched, so the
// canvas never gets tainted and can always be exported.

const W = 1080;
const H = 1350;
const MONO = '"SF Mono", Menlo, Consolas, "Courier New", monospace';
const INK = '#1d1b20';
const FADED = '#77737f';

const canvas = document.getElementById('receipt');
const ctx = canvas.getContext('2d');
const note = document.getElementById('note');

// Made-up tracks for the "Sample" receipt, used for previews and launch posts.
const SAMPLE = {
  seconds: 11 * 3600 + 24 * 60,
  dodged: 1180,
  shortsSkipped: 24,
  shortsWatched: 0,
  tracks: {
    a: { t: 'Midnight Drive', a: 'Neon Harbor', s: 2460 },
    b: { t: 'Paper Lanterns', a: 'Juniper Vale', s: 1980 },
    c: { t: 'Slow Static', a: 'The Quiet Hours', s: 1730 },
    d: { t: 'Gold in the Rain', a: 'Neon Harbor', s: 1510 },
    e: { t: 'Satellite Hearts', a: 'Mira Sol', s: 1320 },
    ...Object.fromEntries(Array.from({ length: 137 }, (_, i) => [`x${i}`, { t: '', a: '', s: 200 }])),
  },
};

let current = null; // { summary, start, sample }

async function load(which) {
  for (const b of document.querySelectorAll('.weeks button')) {
    b.setAttribute('aria-pressed', String(b.dataset.week === which));
  }
  const start = weekStart();
  if (which === 'last') start.setDate(start.getDate() - 7);

  let week = SAMPLE;
  if (which !== 'sample') {
    const key = weekKey(start);
    week = (await chrome.storage.local.get(key))[key] || emptyWeek();
  }
  current = { summary: summarize(week), start, sample: which === 'sample' };
  draw(current);
  note.textContent =
    !current.sample && current.summary.seconds < 60 ? 'Not much listening yet. Play some music on YouTube and come back.' : '';
}

// ---------- Drawing ----------

function draw({ summary, start, sample }) {
  // Background: deep violet to plum, with two soft glows.
  const bg = ctx.createLinearGradient(0, 0, W, H);
  bg.addColorStop(0, '#1f1036');
  bg.addColorStop(1, '#3d0f2f');
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, W, H);
  glow(180, 160, 520, 'rgba(124, 58, 237, 0.55)');
  glow(940, 1220, 560, 'rgba(236, 72, 153, 0.45)');

  const PW = 780;
  const PH = 1250;
  ctx.save();
  ctx.translate(W / 2, H / 2);
  ctx.rotate(-0.018);
  ctx.translate(-PW / 2, -PH / 2);

  paper(PW, PH);

  const L = 64;
  const R = PW - 64;
  let y = 104;

  text('MUSIC FOCUS', PW / 2, y, `700 54px ${MONO}`, INK, 'center', 6);
  y += 46;
  text('WEEKLY LISTENING RECEIPT', PW / 2, y, `500 22px ${MONO}`, FADED, 'center', 3);
  y += 34;
  text(range(start), PW / 2, y, `500 22px ${MONO}`, FADED, 'center', 2);
  y += 34;
  dashes(L, R, y);
  y += 48;

  text('TOP TRACKS', L, y, `700 24px ${MONO}`, INK, 'left', 2);
  text('MIN', R, y, `700 24px ${MONO}`, INK, 'right', 2);
  y += 20;

  if (summary.top.length === 0) {
    y += 46;
    text('NO SONGS YET', PW / 2, y, `500 24px ${MONO}`, FADED, 'center', 2);
    y += 30;
  }
  summary.top.forEach((t, i) => {
    y += 46;
    const minutes = String(Math.round(t.s / 60));
    ctx.font = `700 26px ${MONO}`;
    const minutesW = ctx.measureText(minutes).width;
    const num = `${String(i + 1).padStart(2, '0')} `;
    const numW = ctx.measureText(num).width;
    text(num, L, y, ctx.font, FADED);
    text(fit(upper(t.t) || 'UNTITLED', R - L - numW - minutesW - 24, ctx.font), L + numW, y, ctx.font, INK);
    text(minutes, R, y, ctx.font, INK, 'right');
    y += 28;
    ctx.font = `400 21px ${MONO}`;
    text(fit(upper(t.a), R - L - numW - minutesW - 24, ctx.font), L + numW, y, ctx.font, FADED);
  });

  y += 34;
  dashes(L, R, y);
  y += 50;

  const rows = [
    ['SONGS PLAYED', summary.songs.toLocaleString('en-US')],
    ['TOP ARTIST', upper(summary.topArtist) || '-'],
    ['RABBIT HOLES DODGED', summary.dodged.toLocaleString('en-US')],
    ['SHORTS WATCHED', summary.shortsWatched.toLocaleString('en-US')],
  ];
  for (const [label, value] of rows) {
    leader(label, value, L, R, y, `500 24px ${MONO}`);
    y += 42;
  }

  y += 2;
  dashes(L, R, y);
  dashes(L, R, y + 8);
  y += 62;
  text('TOTAL LISTENING', L, y, `700 30px ${MONO}`, INK, 'left', 1);
  text(upper(hoursMinutes(summary.seconds)), R, y, `800 44px ${MONO}`, INK, 'right', 1);
  y += 34;
  dashes(L, R, y);

  y += 40;
  barcode(L + 70, R - 70, y, 78, range(start) + summary.seconds);
  if (sample) stamp(PW / 2, y + 40);
  y += 124;
  text('THANK YOU FOR LISTENING', PW / 2, y, `700 24px ${MONO}`, INK, 'center', 3);
  y += 34;
  text(`MUSIC FOCUS · BY ${upper(STUDIO.handle || STUDIO.name)}`, PW / 2, y, `500 19px ${MONO}`, FADED, 'center', 1);

  ctx.restore();
}

function glow(x, y, r, color) {
  const g = ctx.createRadialGradient(x, y, 0, x, y, r);
  g.addColorStop(0, color);
  g.addColorStop(1, 'transparent');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
}

// Thermal paper with torn zigzag edges top and bottom.
function paper(w, h) {
  const tooth = 18;
  ctx.beginPath();
  ctx.moveTo(0, tooth);
  for (let x = 0; x < w; x += tooth) {
    ctx.lineTo(x + tooth / 2, 0);
    ctx.lineTo(x + tooth, tooth);
  }
  ctx.lineTo(w, h - tooth);
  for (let x = w; x > 0; x -= tooth) {
    ctx.lineTo(x - tooth / 2, h);
    ctx.lineTo(x - tooth, h - tooth);
  }
  ctx.closePath();

  ctx.save();
  ctx.shadowColor = 'rgba(0, 0, 0, 0.45)';
  ctx.shadowBlur = 60;
  ctx.shadowOffsetY = 24;
  const fill = ctx.createLinearGradient(0, 0, 0, h);
  fill.addColorStop(0, '#fdfcf8');
  fill.addColorStop(1, '#f3f0e8');
  ctx.fillStyle = fill;
  ctx.fill();
  ctx.restore();
}

function text(str, x, y, font, color, align = 'left', spacing = 0) {
  ctx.font = font;
  ctx.fillStyle = color;
  ctx.textAlign = align;
  ctx.textBaseline = 'alphabetic';
  ctx.letterSpacing = `${spacing}px`;
  ctx.fillText(str, x, y);
  ctx.letterSpacing = '0px';
}

// "LABEL ............ VALUE"
function leader(label, value, left, right, y, font) {
  ctx.font = font;
  const maxValueW = (right - left) * 0.5;
  value = fit(value, maxValueW, font);
  const lw = ctx.measureText(label).width;
  const vw = ctx.measureText(value).width;
  const dotW = ctx.measureText('.').width;
  const dots = '.'.repeat(Math.max(0, Math.floor((right - left - lw - vw - 28) / dotW)));
  text(label, left, y, font, INK);
  text(dots, left + lw + 14, y, font, '#b8b4bf');
  text(value, right, y, font, INK, 'right');
}

function dashes(left, right, y) {
  ctx.save();
  ctx.strokeStyle = '#a9a5b0';
  ctx.lineWidth = 2;
  ctx.setLineDash([10, 8]);
  ctx.beginPath();
  ctx.moveTo(left, y);
  ctx.lineTo(right, y);
  ctx.stroke();
  ctx.restore();
}

// Decorative barcode, stable for a given week.
function barcode(left, right, y, height, seed) {
  let h = 2166136261;
  for (const c of String(seed)) h = Math.imul(h ^ c.charCodeAt(0), 16777619);
  const rand = () => ((h = Math.imul(h ^ (h >>> 15), 2246822507) ^ Math.imul(h ^ (h >>> 13), 3266489909)) >>> 0) / 4294967296;
  ctx.fillStyle = INK;
  for (let x = left; x < right; ) {
    const bar = 2 + Math.floor(rand() * 5);
    if (rand() > 0.35) ctx.fillRect(x, y, bar, height);
    x += bar + 2 + Math.floor(rand() * 4);
  }
}

function stamp(x, y) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(-0.12);
  ctx.fillStyle = 'rgba(250, 248, 242, 0.92)';
  ctx.fillRect(-110, -38, 220, 76);
  ctx.strokeStyle = 'rgba(220, 38, 38, 0.75)';
  ctx.lineWidth = 5;
  ctx.strokeRect(-110, -38, 220, 76);
  text('SAMPLE', 0, 16, `800 46px ${MONO}`, 'rgba(220, 38, 38, 0.75)', 'center', 6);
  ctx.restore();
}

function fit(str, maxWidth, font) {
  ctx.font = font;
  if (ctx.measureText(str).width <= maxWidth) return str;
  while (str && ctx.measureText(`${str}…`).width > maxWidth) str = str.slice(0, -1);
  return `${str.trimEnd()}…`;
}

function upper(str) {
  return (str || '').toUpperCase();
}

function range(start) {
  const end = new Date(start);
  end.setDate(end.getDate() + 6);
  const fmt = (d) => d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }).toUpperCase();
  return `${fmt(start)} – ${fmt(end)}, ${end.getFullYear()}`;
}

// ---------- Actions ----------

function pngBlob() {
  return new Promise((resolve) => canvas.toBlob(resolve, 'image/png'));
}

async function copyImage() {
  await navigator.clipboard.write([new ClipboardItem({ 'image/png': pngBlob() })]);
}

function postText({ summary }) {
  const shorts = summary.shortsWatched === 0 ? 'watched 0 Shorts' : `only watched ${summary.shortsWatched} Shorts`;
  const via = STUDIO.handle ? `\n\nvia ${STUDIO.handle}` : '';
  return `This week I listened to ${hoursMinutes(summary.seconds)} of music on YouTube and ${shorts}.\n\nYouTube, but just the music.${via}`;
}

document.querySelector('.weeks').addEventListener('click', (e) => {
  const which = e.target.closest('button')?.dataset.week;
  if (which) load(which);
});

document.getElementById('download').addEventListener('click', async () => {
  const url = URL.createObjectURL(await pngBlob());
  const a = Object.assign(document.createElement('a'), {
    href: url,
    download: `focus-receipt-${weekKey(current.start).slice(5)}.png`,
  });
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  note.textContent = 'Saved.';
});

document.getElementById('copy').addEventListener('click', async () => {
  try {
    await copyImage();
    note.textContent = 'Copied. Paste it anywhere.';
  } catch {
    note.textContent = "Couldn't copy. Use Download instead.";
  }
});

document.getElementById('post').addEventListener('click', async () => {
  try {
    await copyImage();
    note.textContent = 'Image copied. Paste it into your post (Cmd/Ctrl+V).';
  } catch {
    note.textContent = "Couldn't copy the image. Download it and attach it to your post.";
  }
  window.open(`https://x.com/intent/post?text=${encodeURIComponent(postText(current))}`, '_blank', 'noopener');
});

load(new URLSearchParams(location.search).get('week') || 'this');
