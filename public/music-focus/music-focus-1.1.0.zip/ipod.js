// Classic skin for the now-playing card: a click-wheel music player with a
// screen that has three views, like the real thing.
//   Now Playing: turn the wheel for volume; press the centre, then turn, to seek.
//   Menu (press MENU): turn to choose, centre to select, MENU to go back.
//   Brick: turn to move the paddle, centre to launch or pause. The song keeps playing.
// Pressing the ring itself: MENU at the top, |<< / >>| skip, bottom plays/pauses.

const WHEEL_STEP_DEG = 18; // degrees of travel per wheel click
const VOLUME_STEP = 0.04;
const SCRUB_STEP = 5; // seconds per click while seeking

const MENU_ITEMS = [
  { label: 'Now Playing', select: (p) => showScreen(p, 'now') },
  { label: 'Brick', select: (p) => openBrick(p) },
  { label: 'Modern Player', select: () => chrome.storage.local.set({ skin: 'modern' }) },
];

const HEADINGS = { now: 'Now Playing', menu: 'Music Focus', brick: 'Brick' };

let wheelAudio = null;

function buildIpod() {
  const p = { screen: 'now', menuIndex: 0 };
  p.art = el('img', { class: 'mf-ipod-art', alt: '' });
  p.title = el('div', { class: 'mf-ipod-title' });
  p.artist = el('div', { class: 'mf-ipod-artist' });
  p.elapsed = el('span', {}, '0:00');
  p.remaining = el('span', {}, '-0:00');
  p.heading = el('span', { class: 'mf-now' }, HEADINGS.now);
  p.menu = el('div', { class: 'mf-ipod-view mf-ipod-menuview', role: 'listbox', 'aria-label': 'Menu' });
  p.canvas = el('canvas', { class: 'mf-ipod-brick', 'aria-label': 'Brick game' });
  p.center = el('button', {
    type: 'button',
    class: 'mf-ipod-center',
    'aria-label': 'Select',
    title: 'Select (on Now Playing: switch the wheel between volume and seeking)',
  });
  p.wheel = el(
    'div',
    {
      class: 'mf-ipod-wheel',
      tabindex: '0',
      role: 'group',
      'aria-label': 'Click wheel. Arrow keys turn it, Enter selects, Escape is MENU, Space plays or pauses.',
    },
    el('span', { class: 'mf-ipod-label mf-ipod-menu' }, 'MENU'),
    el('span', { class: 'mf-ipod-label mf-ipod-prev' }, icon('prev')),
    el('span', { class: 'mf-ipod-label mf-ipod-next' }, icon('next')),
    el('span', { class: 'mf-ipod-label mf-ipod-pp' }, icon('play'), icon('pause')),
    p.center,
  );

  const playingIcon = icon('play');
  const pausedIcon = icon('pause');
  playingIcon.classList.add('mf-ipod-is-playing');
  pausedIcon.classList.add('mf-ipod-is-paused');

  p.root = el(
    'div',
    { class: 'mf-ipod', 'data-screen': 'now' },
    el(
      'div',
      { class: 'mf-ipod-screen' },
      el(
        'div',
        { class: 'mf-ipod-header' },
        el('span', { class: 'mf-ipod-state' }, playingIcon, pausedIcon),
        el('span', {}, p.heading, el('span', { class: 'mf-ad' }, 'Ad')),
        el('span', { class: 'mf-ipod-battery' }),
      ),
      el(
        'div',
        { class: 'mf-ipod-view mf-ipod-nowview' },
        el(
          'div',
          { class: 'mf-ipod-body' },
          el('div', { class: 'mf-ipod-art-wrap' }, p.art),
          el('div', { class: 'mf-ipod-text' }, p.title, p.artist),
        ),
        el(
          'div',
          { class: 'mf-ipod-footer' },
          el('div', { class: 'mf-ipod-mode' }, el('span', { class: 'mf-ipod-mode-vol' }, 'Volume'), el('span', { class: 'mf-ipod-mode-scrub' }, 'Seeking')),
          el('div', { class: 'mf-ipod-bar' }, el('i')),
          el('div', { class: 'mf-ipod-times' }, p.elapsed, p.remaining),
        ),
      ),
      p.menu,
      el('div', { class: 'mf-ipod-view mf-ipod-brickview' }, p.canvas),
    ),
    p.wheel,
  );

  renderMenu(p);
  wireWheel(p);
  return p;
}

// ---------- Screens ----------

function showScreen(p, screen) {
  if (p.screen === 'brick' && screen !== 'brick') pauseBrick(p);
  p.screen = screen;
  p.root.dataset.screen = screen;
  p.heading.textContent = HEADINGS[screen];
  if (screen !== 'now') {
    clearTimeout(p.modeTimer);
    p.root.classList.remove('mf-vol', 'mf-scrub');
  }
  if (screen === 'menu') renderMenu(p);
}

function renderMenu(p) {
  p.menu.replaceChildren(
    ...MENU_ITEMS.map((item, i) =>
      el(
        'div',
        { class: 'mf-ipod-item', role: 'option', 'aria-selected': String(i === p.menuIndex) },
        el('span', {}, item.label),
        el('span', { class: 'mf-ipod-chevron' }, '›'),
      ),
    ),
  );
}

function pressMenu(p) {
  if (p.screen === 'now') showScreen(p, 'menu');
  else if (p.screen === 'brick') showScreen(p, 'menu');
  else showScreen(p, 'now');
}

function pressCenter(p) {
  wheelClick();
  if (p.screen === 'menu') MENU_ITEMS[p.menuIndex].select(p);
  else if (p.screen === 'brick') brickAction(p);
  else toggleScrub(p);
}

// ---------- The wheel ----------

function wireWheel(p) {
  let drag = null;
  let scrolled = 0;

  const angleOf = (e) => {
    const r = p.wheel.getBoundingClientRect();
    return (Math.atan2(e.clientY - r.top - r.height / 2, e.clientX - r.left - r.width / 2) * 180) / Math.PI;
  };

  p.wheel.addEventListener('pointerdown', (e) => {
    if (e.button !== 0 || p.center.contains(e.target)) return;
    p.wheel.setPointerCapture(e.pointerId);
    const a = angleOf(e);
    drag = { start: a, last: a, acc: 0, travel: 0 };
  });

  p.wheel.addEventListener('pointermove', (e) => {
    if (!drag) return;
    const a = angleOf(e);
    let d = a - drag.last;
    if (d > 180) d -= 360;
    if (d < -180) d += 360;
    drag.last = a;
    drag.acc += d;
    drag.travel += Math.abs(d);
    while (Math.abs(drag.acc) >= WHEEL_STEP_DEG) {
      const dir = Math.sign(drag.acc);
      drag.acc -= dir * WHEEL_STEP_DEG;
      turnWheel(p, dir);
    }
  });

  // A press without turning is a button press on that part of the ring.
  p.wheel.addEventListener('pointerup', () => {
    if (drag && drag.travel < 8) pressWheel(p, drag.start);
    drag = null;
  });
  p.wheel.addEventListener('pointercancel', () => (drag = null));

  p.wheel.addEventListener(
    'wheel',
    (e) => {
      e.preventDefault();
      scrolled += e.deltaY;
      while (Math.abs(scrolled) >= 40) {
        const dir = Math.sign(scrolled);
        scrolled -= dir * 40;
        turnWheel(p, -dir);
      }
    },
    { passive: false },
  );

  p.wheel.addEventListener('keydown', (e) => {
    const action = {
      // Up means "up the list" in the menu but "louder" on Now Playing.
      ArrowUp: () => turnWheel(p, p.screen === 'menu' ? -1 : 1),
      ArrowDown: () => turnWheel(p, p.screen === 'menu' ? 1 : -1),
      ArrowLeft: () => turnWheel(p, -1),
      ArrowRight: () => turnWheel(p, 1),
      ' ': togglePlay,
      Enter: () => pressCenter(p),
      Escape: () => pressMenu(p),
    }[e.key];
    if (!action) return;
    e.preventDefault();
    action();
  });

  p.center.addEventListener('click', () => pressCenter(p));
}

function pressWheel(p, angle) {
  wheelClick();
  // 0° is the right edge and angles grow clockwise, so the top of the ring is -90°.
  if (angle >= -135 && angle < -45) pressMenu(p);
  else if (angle >= -45 && angle < 45) next();
  else if (angle >= 45 && angle < 135) togglePlay();
  else previous();
}

// Clockwise (dir 1) goes down a menu, right in Brick, and up in volume or time.
function turnWheel(p, dir) {
  if (p.screen === 'menu') {
    const i = Math.min(Math.max(p.menuIndex + dir, 0), MENU_ITEMS.length - 1);
    if (i === p.menuIndex) return; // menus stop at the ends, like the real thing
    p.menuIndex = i;
    wheelClick();
    renderMenu(p);
    return;
  }
  if (p.screen === 'brick') {
    wheelClick();
    moveBrickPaddle(p, dir);
    return;
  }
  const v = ui?.video;
  if (!v) return;
  wheelClick();
  if (p.root.classList.contains('mf-scrub')) {
    const end = Number.isFinite(v.duration) ? v.duration : v.currentTime;
    v.currentTime = Math.min(Math.max(v.currentTime + dir * SCRUB_STEP, 0), end);
    holdMode(p, 'mf-scrub');
  } else {
    v.muted = false;
    v.volume = Math.min(Math.max(Math.round((v.volume + dir * VOLUME_STEP) * 100) / 100, 0), 1);
    holdMode(p, 'mf-vol');
  }
}

function toggleScrub(p) {
  if (p.root.classList.contains('mf-scrub')) {
    clearTimeout(p.modeTimer);
    p.root.classList.remove('mf-scrub');
  } else {
    p.root.classList.remove('mf-vol');
    holdMode(p, 'mf-scrub');
  }
}

// Volume shows briefly; seeking stays on until the wheel rests for a few seconds.
function holdMode(p, mode) {
  p.root.classList.add(mode);
  clearTimeout(p.modeTimer);
  p.modeTimer = setTimeout(() => p.root.classList.remove('mf-vol', 'mf-scrub'), mode === 'mf-scrub' ? 5000 : 1500);
}

// The tiny tick the real click wheel makes.
function wheelClick() {
  try {
    wheelAudio ??= new AudioContext();
    const t = wheelAudio.currentTime;
    const osc = wheelAudio.createOscillator();
    const gain = wheelAudio.createGain();
    osc.type = 'square';
    osc.frequency.value = 2200;
    gain.gain.setValueAtTime(0.03, t);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.012);
    osc.connect(gain).connect(wheelAudio.destination);
    osc.start(t);
    osc.stop(t + 0.015);
  } catch {
    // Sound is a nicety; the wheel works without it.
  }
}

// ---------- Brick ----------
// Drawn on a 200×130 board (scaled up for sharpness). The ball moves in board
// pixels per 60 Hz frame; the paddle moves a fixed step per wheel click.

const BOARD = { w: 200, h: 130, scale: 3 };
const BRICKS = { rows: 5, cols: 10, top: 16, h: 6, gap: 1, side: 2 };
const BRICK_COLORS = ['#e53935', '#fb8c00', '#fdd835', '#43a047', '#1e88e5'];
const PADDLE = { w: 34, h: 4, y: 120, step: 9 };
const BALL = { r: 2.5, speed: 1.7 };

function newBrickGame(best = 0) {
  return {
    bricks: new Array(BRICKS.rows * BRICKS.cols).fill(true),
    paddle: BOARD.w / 2,
    ball: { x: BOARD.w / 2, y: PADDLE.y - BALL.r, vx: 0, vy: 0 },
    speed: BALL.speed,
    launched: false,
    paused: false,
    over: false,
    lives: 3,
    score: 0,
    level: 1,
    best,
  };
}

function openBrick(p) {
  showScreen(p, 'brick');
  if (!p.game) {
    p.game = newBrickGame();
    chrome.storage.local.get({ brickBest: 0 }, (s) => (p.game.best = Math.max(p.game.best, s.brickBest)));
  }
  p.game.paused = false;
  const c = p.canvas;
  if (c.width !== BOARD.w * BOARD.scale) {
    c.width = BOARD.w * BOARD.scale;
    c.height = BOARD.h * BOARD.scale;
  }
  p.lastTick = null;
  cancelAnimationFrame(p.raf);
  p.raf = requestAnimationFrame((t) => brickLoop(p, t));
}

function pauseBrick(p) {
  cancelAnimationFrame(p.raf);
  if (p.game) p.game.paused = true;
}

function brickAction(p) {
  const g = p.game;
  if (g.over) {
    p.game = newBrickGame(g.best);
  } else if (!g.launched) {
    g.launched = true;
    const angle = (Math.random() * 0.8 - 0.4) - Math.PI / 2;
    g.ball.vx = Math.cos(angle) * g.speed;
    g.ball.vy = Math.sin(angle) * g.speed;
  } else {
    g.paused = !g.paused;
  }
}

function moveBrickPaddle(p, dir) {
  const g = p.game;
  if (!g || g.paused || g.over) return;
  g.paddle = Math.min(Math.max(g.paddle + dir * PADDLE.step, PADDLE.w / 2), BOARD.w - PADDLE.w / 2);
}

function brickLoop(p, now) {
  if (p.screen !== 'brick') return;
  const dt = p.lastTick === null ? 1 : Math.min((now - p.lastTick) / (1000 / 60), 2);
  p.lastTick = now;
  if (!document.hidden) stepBrick(p.game, dt);
  drawBrick(p);
  p.raf = requestAnimationFrame((t) => brickLoop(p, t));
}

function stepBrick(g, dt) {
  const b = g.ball;
  if (g.over || g.paused) return;
  if (!g.launched) {
    b.x = g.paddle;
    b.y = PADDLE.y - BALL.r;
    return;
  }
  b.x += b.vx * dt;
  b.y += b.vy * dt;

  // Walls and ceiling
  if (b.x < BALL.r) (b.x = BALL.r), (b.vx = Math.abs(b.vx));
  if (b.x > BOARD.w - BALL.r) (b.x = BOARD.w - BALL.r), (b.vx = -Math.abs(b.vx));
  if (b.y < 11 + BALL.r) (b.y = 11 + BALL.r), (b.vy = Math.abs(b.vy));

  // Paddle: where the ball lands sets the bounce angle.
  const half = PADDLE.w / 2;
  if (b.vy > 0 && b.y + BALL.r >= PADDLE.y && b.y + BALL.r <= PADDLE.y + PADDLE.h + 3 && Math.abs(b.x - g.paddle) <= half + BALL.r) {
    const hit = Math.max(-1, Math.min(1, (b.x - g.paddle) / half));
    const angle = -Math.PI / 2 + hit * 1.05;
    b.vx = Math.cos(angle) * g.speed;
    b.vy = Math.sin(angle) * g.speed;
    b.y = PADDLE.y - BALL.r;
  }

  // Bricks: one hit per step, bounce off the side we came in from.
  const bw = (BOARD.w - BRICKS.side * 2 - (BRICKS.cols - 1) * BRICKS.gap) / BRICKS.cols;
  const col = Math.floor((b.x - BRICKS.side) / (bw + BRICKS.gap));
  const row = Math.floor((b.y - BRICKS.top) / (BRICKS.h + BRICKS.gap));
  if (row >= 0 && row < BRICKS.rows && col >= 0 && col < BRICKS.cols && g.bricks[row * BRICKS.cols + col]) {
    g.bricks[row * BRICKS.cols + col] = false;
    g.score += (BRICKS.rows - row) * 10;
    const prevRow = Math.floor((b.y - b.vy * dt - BRICKS.top) / (BRICKS.h + BRICKS.gap));
    if (prevRow !== row) b.vy = -b.vy;
    else b.vx = -b.vx;
    if (g.bricks.every((alive) => !alive)) {
      g.level++;
      g.speed *= 1.12;
      g.bricks.fill(true);
      g.launched = false;
    }
  }

  // Missed the ball
  if (b.y > BOARD.h + BALL.r) {
    g.lives--;
    g.launched = false;
    if (g.lives <= 0) {
      g.over = true;
      if (g.score > g.best) {
        g.best = g.score;
        chrome.storage.local.set({ brickBest: g.best });
      }
    }
  }
}

function drawBrick(p) {
  const g = p.game;
  const ctx = p.canvas.getContext('2d');
  ctx.setTransform(BOARD.scale, 0, 0, BOARD.scale, 0, 0);
  ctx.fillStyle = '#fff';
  ctx.fillRect(0, 0, BOARD.w, BOARD.h);

  ctx.fillStyle = '#111';
  ctx.font = '700 7px "Helvetica Neue", Helvetica, Arial, sans-serif';
  ctx.textBaseline = 'top';
  ctx.textAlign = 'left';
  ctx.fillText(`Score ${g.score}`, 3, 2);
  ctx.textAlign = 'right';
  ctx.fillText(`Level ${g.level}  ${'●'.repeat(Math.max(g.lives, 0))}`, BOARD.w - 3, 2);
  ctx.fillRect(0, 11, BOARD.w, 0.5);

  const bw = (BOARD.w - BRICKS.side * 2 - (BRICKS.cols - 1) * BRICKS.gap) / BRICKS.cols;
  for (let r = 0; r < BRICKS.rows; r++) {
    ctx.fillStyle = BRICK_COLORS[r];
    for (let c = 0; c < BRICKS.cols; c++) {
      if (!g.bricks[r * BRICKS.cols + c]) continue;
      ctx.fillRect(BRICKS.side + c * (bw + BRICKS.gap), BRICKS.top + r * (BRICKS.h + BRICKS.gap), bw, BRICKS.h);
    }
  }

  ctx.fillStyle = '#111';
  ctx.fillRect(g.paddle - PADDLE.w / 2, PADDLE.y, PADDLE.w, PADDLE.h);
  ctx.beginPath();
  ctx.arc(g.ball.x, g.ball.y, BALL.r, 0, Math.PI * 2);
  ctx.fill();

  const message = g.over
    ? ['Game Over', `Score ${g.score} · Best ${g.best}`, 'Press centre to play again']
    : g.paused
      ? ['Paused', 'Press centre to resume']
      : !g.launched
        ? ['Turn the wheel to move', 'Press centre to launch']
        : null;
  if (message) {
    ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
    ctx.fillRect(0, 66, BOARD.w, 12 + message.length * 10);
    ctx.fillStyle = '#111';
    ctx.textAlign = 'center';
    message.forEach((line, i) => {
      ctx.font = `${i === 0 ? 700 : 500} ${i === 0 ? 9 : 7}px "Helvetica Neue", Helvetica, Arial, sans-serif`;
      ctx.fillText(line, BOARD.w / 2, 71 + i * 11);
    });
  }
}

// ---------- Kept in sync by content.js ----------

function ipodSetTrack(p, title, artist) {
  p.title.textContent = title;
  p.artist.textContent = artist;
}

function ipodSyncTime(p, current, duration) {
  const finite = Number.isFinite(duration) && duration > 0;
  p.root.style.setProperty('--p', `${finite ? (current / duration) * 100 : 0}%`);
  p.elapsed.textContent = clock(current);
  p.remaining.textContent = duration === Infinity ? 'Live' : `-${clock(finite ? duration - current : 0)}`;
}

function ipodSyncVolume(p, level) {
  p.root.style.setProperty('--v', `${level * 100}%`);
}
