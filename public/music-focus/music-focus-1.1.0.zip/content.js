// Music Focus: when enabled, <html> gets the "mf-on" class and content.css
// hides everything that isn't music. This script builds the parts CSS can't:
// the now-playing card over the player, the search page that replaces the
// home feed, and the redirect from Shorts to the plain player. The Classic skin
// (click wheel, menu and Brick) lives in ipod.js and the weekly listening stats in stats.js.

let enabled = true;
let skin = 'modern'; // 'modern' | 'ipod'
let ui = null; // now-playing card elements, built once per player
let binding = null; // AbortController for listeners on the current <video>

function apply() {
  document.documentElement.classList.toggle('mf-on', enabled);
  document.documentElement.dataset.mfSkin = skin;
  noteShortsVisit();
  if (!enabled) return;
  redirectShorts();
  renderHome();
  renderCard();
}

function redirectShorts() {
  const m = location.pathname.match(/^\/shorts\/([\w-]+)/);
  if (!m) return;
  noteShortSkipped();
  flushStats().finally(() => location.replace(`/watch?v=${m[1]}`));
}

// ---------- Home: a search page instead of the feed ----------

const MOODS = ['Lo-fi', 'Jazz', 'Classical', 'Indie', 'Hip-hop', 'Acoustic', 'Focus', 'Workout'];

function renderHome() {
  const browse = document.querySelector('ytd-browse[page-subtype="home"]');
  if (!browse || browse.querySelector(':scope > .mf-home')) return;

  const input = el('input', {
    type: 'search',
    placeholder: 'Songs, artists, albums',
    'aria-label': 'Search music',
    autocomplete: 'off',
  });
  const form = el(
    'form',
    { class: 'mf-search', onsubmit: (e) => (e.preventDefault(), search(input.value)) },
    icon('search'),
    input,
    el('button', { type: 'submit' }, 'Search'),
  );
  const chips = MOODS.map((mood) =>
    el('button', { type: 'button', class: 'mf-chip', onclick: () => search(`${mood} music`) }, mood),
  );

  browse.prepend(
    el(
      'section',
      { class: 'mf-home' },
      equalizer(),
      el('h1', {}, 'What do you want to listen to?'),
      form,
      el('div', { class: 'mf-chips' }, ...chips),
    ),
  );
}

function search(query) {
  query = query.trim();
  if (query) location.href = `/results?search_query=${encodeURIComponent(query)}`;
}

// ---------- Watch page: the now-playing card ----------

function renderCard() {
  if (location.pathname !== '/watch') return;
  const player = document.querySelector('#movie_player');
  const id = new URLSearchParams(location.search).get('v');
  if (!player || !id) return;

  if (!ui || !player.contains(ui.card)) ui = buildCard(player);

  if (ui.card.dataset.id !== id) {
    ui.card.dataset.id = id;
    const art = `https://i.ytimg.com/vi/${id}/hqdefault.jpg`;
    ui.art.src = art;
    ui.ipod.art.src = art;
    resetListening();
    ui.card.style.setProperty('--mf-art', `url("${art}")`);
  }
  const { title, artist } = songInfo();
  ui.title.textContent = title;
  ui.artist.textContent = artist;
  ipodSetTrack(ui.ipod, title, artist);
  noteTrack(id, title, artist);

  const video = player.querySelector('video');
  if (video && video !== ui.video) bindVideo(video);
  syncRepeat();
}

function buildCard(player) {
  const u = {};
  u.art = el('img', { class: 'mf-art', alt: '', onclick: togglePlay });
  u.title = el('div', { class: 'mf-title' });
  u.artist = el('div', { class: 'mf-artist' });
  u.seek = slider('mf-seek', 'Seek', 1000);
  u.elapsed = el('span', {}, '0:00');
  u.duration = el('span', {}, '0:00');
  u.repeat = iconButton('repeat', 'Repeat', toggleRepeat, 'mf-repeat');
  u.play = iconButton('play', 'Play', togglePlay, 'mf-play');
  u.mute = iconButton('volume', 'Mute', toggleMute);
  u.volume = slider('mf-vol', 'Volume', 100);
  u.ipod = buildIpod();

  u.card = el(
    'div',
    { class: 'mf-card' },
    el(
      'div',
      { class: 'mf-inner' },
      el('div', { class: 'mf-art-wrap' }, u.art),
      el(
        'div',
        { class: 'mf-panel' },
        el(
          'div',
          { class: 'mf-kicker' },
          equalizer(),
          el('span', { class: 'mf-now' }, 'Now playing'),
          el('span', { class: 'mf-ad' }, 'Ad playing'),
        ),
        u.title,
        u.artist,
        el('div', { class: 'mf-progress' }, u.seek, el('div', { class: 'mf-times' }, u.elapsed, u.duration)),
        el(
          'div',
          { class: 'mf-controls' },
          u.repeat,
          el(
            'div',
            { class: 'mf-transport' },
            iconButton('prev', 'Previous', previous),
            u.play,
            iconButton('next', 'Next', next),
          ),
          el('div', { class: 'mf-volume' }, u.mute, u.volume),
        ),
      ),
    ),
    u.ipod.root,
  );

  // Keep clicks and keys inside the card from also reaching YouTube's player,
  // which would toggle playback or fullscreen a second time.
  for (const type of ['click', 'dblclick', 'mousedown', 'mouseup', 'pointerdown', 'pointerup', 'keydown']) {
    u.card.addEventListener(type, (e) => e.stopPropagation());
  }

  u.seek.addEventListener('input', previewSeek);
  u.seek.addEventListener('change', commitSeek);
  u.volume.addEventListener('input', setVolume);

  player.appendChild(u.card);
  return u;
}

function bindVideo(video) {
  binding?.abort();
  binding = new AbortController();
  ui.video = video;
  const on = (types, fn) => types.forEach((t) => video.addEventListener(t, fn, { signal: binding.signal }));
  on(['timeupdate', 'durationchange', 'loadedmetadata', 'emptied'], syncTime);
  on(['play', 'pause', 'ended', 'emptied'], syncPlaying);
  on(['volumechange'], syncVolume);
  on(['timeupdate'], () => trackListening(video, ui.card.dataset.id));
  on(['seeking', 'emptied'], resetListening);
  syncTime();
  syncPlaying();
  syncVolume();
}

// ---------- Playback actions ----------

function togglePlay() {
  const v = ui?.video;
  if (v) v.paused ? v.play() : v.pause();
}

function previous() {
  const v = ui?.video;
  if (!v) return;
  // Like a music player: restart the song unless we're at its very start in a playlist.
  const prev = document.querySelector('#movie_player .ytp-prev-button');
  if (v.currentTime < 3 && prev && prev.style.display !== 'none') prev.click();
  else v.currentTime = 0;
}

function next() {
  document.querySelector('#movie_player .ytp-next-button')?.click();
}

function toggleRepeat() {
  if (!ui?.video) return;
  ui.video.loop = !ui.video.loop;
  syncRepeat();
}

function toggleMute() {
  const v = ui?.video;
  if (!v) return;
  if (v.muted || v.volume === 0) {
    v.muted = false;
    if (v.volume === 0) v.volume = 0.5;
  } else {
    v.muted = true;
  }
}

function setVolume() {
  const v = ui?.video;
  if (!v) return;
  const value = Number(ui.volume.value);
  v.volume = value / 100;
  v.muted = value === 0;
}

function previewSeek() {
  ui.seeking = true;
  setRange(ui.seek, ui.seek.value);
  const d = ui.video?.duration;
  if (Number.isFinite(d)) ui.elapsed.textContent = clock((ui.seek.value / 1000) * d);
}

function commitSeek() {
  const d = ui.video?.duration;
  if (Number.isFinite(d)) ui.video.currentTime = (ui.seek.value / 1000) * d;
  ui.seeking = false;
  syncTime();
}

// ---------- Keep the card in sync with the <video> ----------

function syncTime() {
  if (!ui?.video || ui.seeking) return;
  const { currentTime, duration } = ui.video;
  const progress = Number.isFinite(duration) && duration > 0 ? currentTime / duration : 0;
  setRange(ui.seek, progress * 1000);
  ui.elapsed.textContent = clock(currentTime);
  ui.duration.textContent = duration === Infinity ? 'Live' : clock(duration);
  ipodSyncTime(ui.ipod, currentTime, duration);
}

function syncPlaying() {
  const paused = ui.video.paused;
  ui.play.replaceChildren(icon(paused ? 'play' : 'pause'));
  ui.play.setAttribute('aria-label', paused ? 'Play' : 'Pause');
  ui.card.classList.toggle('mf-paused', paused);
}

function syncVolume() {
  const { muted, volume } = ui.video;
  const silent = muted || volume === 0;
  setRange(ui.volume, silent ? 0 : Math.round(volume * 100));
  ui.mute.replaceChildren(icon(silent ? 'muted' : 'volume'));
  ui.mute.setAttribute('aria-label', silent ? 'Unmute' : 'Mute');
  ipodSyncVolume(ui.ipod, silent ? 0 : volume);
}

function syncRepeat() {
  ui?.repeat.setAttribute('aria-pressed', String(Boolean(ui.video?.loop)));
}

// ---------- Page metadata ----------

// Bracketed video-world noise: "(Official Music Video)", "[Lyrics]", "(HD)", ...
const NOISE = /\s*[([][^)\]]*\b(official|video|audio|lyrics?|visuali[sz]er|hd|4k|mv|remaster(ed)?)\b[^)\]]*[)\]]/gi;

// "Artist - Song (Official Video)" by channel "Artist" -> title "Song", artist "Artist".
function songInfo() {
  const h1 = document.querySelector('ytd-watch-metadata h1');
  const channel = document.querySelector('ytd-watch-metadata ytd-channel-name a');
  let title = (h1?.textContent.trim() || document.title.replace(/ - YouTube$/, '')).replace(NOISE, '').trim();
  let artist = channel?.textContent.trim().replace(/ - Topic$/, '').replace(/VEVO$/, '') || '';

  const dash = title.match(/^(.+?)\s+[-–—]\s+(.+)$/);
  if (dash) {
    artist = dash[1];
    title = dash[2];
  }
  return { title, artist };
}

// ---------- DOM helpers ----------
// Built with DOM APIs rather than innerHTML because YouTube enforces Trusted Types.

function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(attrs)) {
    if (typeof value === 'function') node.addEventListener(key.slice(2), value);
    else node.setAttribute(key, value);
  }
  node.append(...children);
  return node;
}

const ICONS = {
  play: 'M8 5.14v13.72a1 1 0 0 0 1.5.86l11-6.86a1 1 0 0 0 0-1.72l-11-6.86A1 1 0 0 0 8 5.14z',
  pause: 'M7 4h3a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1zm7 0h3a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1h-3a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1z',
  prev: 'M6 6h2v12H6zm3.5 6 8.5 6V6z',
  next: 'M6 18l8.5-6L6 6v12zM16 6v12h2V6h-2z',
  repeat: 'M7 7h10v3l4-4-4-4v3H5v6h2V7zm10 10H7v-3l-4 4 4 4v-3h12v-6h-2v4z',
  volume:
    'M3 9v6h4l5 5V4L7 9H3zm13.5 3A4.5 4.5 0 0 0 14 7.97v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z',
  muted:
    'M16.5 12A4.5 4.5 0 0 0 14 7.97v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51A8.8 8.8 0 0 0 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3 3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06a8.99 8.99 0 0 0 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4 9.91 6.09 12 8.18V4z',
  search:
    'M15.5 14h-.79l-.28-.27A6.47 6.47 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z',
};

function icon(name) {
  const ns = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(ns, 'svg');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('aria-hidden', 'true');
  const path = document.createElementNS(ns, 'path');
  path.setAttribute('d', ICONS[name]);
  svg.append(path);
  return svg;
}

function iconButton(name, label, onClick, extraClass = '') {
  return el(
    'button',
    { type: 'button', class: `mf-btn ${extraClass}`.trim(), 'aria-label': label, title: label, onclick: onClick },
    icon(name),
  );
}

function slider(extraClass, label, max) {
  return el('input', {
    type: 'range',
    class: `mf-range ${extraClass}`,
    min: '0',
    max: String(max),
    step: '1',
    value: '0',
    'aria-label': label,
  });
}

function setRange(input, value) {
  input.value = value;
  input.style.setProperty('--p', `${(value / input.max) * 100}%`);
}

function equalizer() {
  return el('span', { class: 'mf-eq', 'aria-hidden': 'true' }, el('i'), el('i'), el('i'), el('i'));
}

function clock(seconds) {
  if (!Number.isFinite(seconds)) return '0:00';
  const s = Math.floor(seconds);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const ss = String(s % 60).padStart(2, '0');
  return h ? `${h}:${String(m).padStart(2, '0')}:${ss}` : `${m}:${ss}`;
}

// ---------- Start (last, so every constant above is initialised) ----------

chrome.storage.local.get({ enabled: true, skin: 'modern' }, (s) => {
  enabled = s.enabled;
  skin = s.skin;
  apply();
});

chrome.storage.onChanged.addListener((changes) => {
  if (!changes.enabled && !changes.skin) return;
  if (changes.enabled) enabled = changes.enabled.newValue;
  if (changes.skin) skin = changes.skin.newValue;
  apply();
});

// YouTube is a single-page app, so re-apply on every in-app navigation.
document.addEventListener('yt-navigate-finish', apply);
document.addEventListener('yt-page-data-updated', apply);

// The song title often lands after navigation finishes; <title> changes with it.
const titleEl = document.querySelector('title');
if (titleEl) {
  new MutationObserver(() => enabled && renderCard()).observe(titleEl, {
    childList: true,
    characterData: true,
    subtree: true,
  });
}
