const toggle = document.getElementById('toggle');
const status = document.getElementById('status');
const skins = document.querySelectorAll('input[name="skin"]');

function renderEnabled(enabled) {
  toggle.checked = enabled;
  status.textContent = enabled ? 'On' : 'Off: regular YouTube';
}

const key = weekKey();
chrome.storage.local.get({ enabled: true, skin: 'modern', [key]: emptyWeek() }, (s) => {
  renderEnabled(s.enabled);
  for (const input of skins) input.checked = input.value === s.skin;

  const week = summarize(s[key]);
  document.getElementById('st-time').textContent = hoursMinutes(week.seconds);
  document.getElementById('st-songs').textContent = week.songs.toLocaleString();
  document.getElementById('st-dodged').textContent = week.dodged.toLocaleString();
});

toggle.addEventListener('change', () => {
  chrome.storage.local.set({ enabled: toggle.checked });
  renderEnabled(toggle.checked);
});

for (const input of skins) {
  input.addEventListener('change', () => chrome.storage.local.set({ skin: input.value }));
}

document.getElementById('receipt').addEventListener('click', () => {
  chrome.tabs.create({ url: 'receipt.html' });
});
