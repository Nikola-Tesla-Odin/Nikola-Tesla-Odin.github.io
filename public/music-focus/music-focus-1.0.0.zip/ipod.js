// iPod Classic skin for the now-playing card: a screen with the Now Playing
// view and a click wheel that works like the real one.
//   Turn the wheel (drag around it, scroll, or arrow keys) -> volume
//   Press the centre button -> turning seeks instead, until you stop for a few seconds
//   MENU -> back to the modern player, |<< / >>| -> previous / next, bottom -> play/pause

const WHEEL_STEP_DEG = 18; // degrees of travel per wheel click
const VOLUME_STEP = 0.04;
const SCRUB_STEP = 5; // seconds per click while seeking

let wheelAudio = null;

function buildIpod() {
  const p = {};
  p.art = el('img', { class: 'mf-ipod-art', alt: '' });
  p.title = el('div', { class: 'mf-ipod-title' });
  p.artist = el('div', { class: 'mf-ipod-artist' });
  p.elapsed = el('span', {}, '0:00');
  p.remaining = el('span', {}, '-0:00');
  p.center = el('button', {
    type: 'button',
    class: 'mf-ipod-center',
    'aria-label': 'Select: turn the wheel to seek',
    title: 'Switch the wheel between volume and seeking',
  });
  p.wheel = el(
    'div',
    {
      class: 'mf-ipod-wheel',
      tabindex: '0',
      role: 'group',
      'aria-label': 'Click wheel. Arrow keys turn it, Space plays or pauses, Enter switches to seeking.',
    },
    el('span', { class: 'mf-ipod-label mf-ipod-menu' }, 'MENU'),
    el('span', { class: 'mf-ipod-label mf-ipod-prev' }, icon('prev')),
    el('span', { class: 'mf-ipod-label mf-ipod-next' }, icon('next')),
    el('span', { class: 'mf-ipod-label mf-ipod-pp' }, icon('play'), icon('pause')),
    p.center,
  );

  const playingIcon = icon('play');
  const pausedIcon = icon('pause');
  playingIcon.classList.add('mf-ipod-is-playing');
  pausedIcon.classList.add('mf-ipod-is-paused');

  p.root = el(
    'div',
    { class: 'mf-ipod' },
    el(
      'div',
      { class: 'mf-ipod-screen' },
      el(
        'div',
        { class: 'mf-ipod-header' },
        el('span', { class: 'mf-ipod-state' }, playingIcon, pausedIcon),
        el('span', {}, el('span', { class: 'mf-now' }, 'Now Playing'), el('span', { class: 'mf-ad' }, 'Ad')),
        el('span', { class: 'mf-ipod-battery' }),
      ),
      el(
        'div',
        { class: 'mf-ipod-body' },
        el('div', { class: 'mf-ipod-art-wrap' }, p.art),
        el('div', { class: 'mf-ipod-text' }, p.title, p.artist),
      ),
      el(
        'div',
        { class: 'mf-ipod-footer' },
        el('div', { class: 'mf-ipod-mode' }, el('span', { class: 'mf-ipod-mode-vol' }, 'Volume'), el('span', { class: 'mf-ipod-mode-scrub' }, 'Seeking')),
        el('div', { class: 'mf-ipod-bar' }, el('i')),
        el('div', { class: 'mf-ipod-times' }, p.elapsed, p.remaining),
      ),
    ),
    p.wheel,
  );

  wireWheel(p);
  return p;
}

function wireWheel(p) {
  let drag = null;
  let scrolled = 0;

  const angleOf = (e) => {
    const r = p.wheel.getBoundingClientRect();
    return (Math.atan2(e.clientY - r.top - r.height / 2, e.clientX - r.left - r.width / 2) * 180) / Math.PI;
  };

  p.wheel.addEventListener('pointerdown', (e) => {
    if (e.button !== 0 || p.center.contains(e.target)) return;
    p.wheel.setPointerCapture(e.pointerId);
    const a = angleOf(e);
    drag = { start: a, last: a, acc: 0, travel: 0 };
  });

  p.wheel.addEventListener('pointermove', (e) => {
    if (!drag) return;
    const a = angleOf(e);
    let d = a - drag.last;
    if (d > 180) d -= 360;
    if (d < -180) d += 360;
    drag.last = a;
    drag.acc += d;
    drag.travel += Math.abs(d);
    while (Math.abs(drag.acc) >= WHEEL_STEP_DEG) {
      const dir = Math.sign(drag.acc);
      drag.acc -= dir * WHEEL_STEP_DEG;
      turnWheel(p, dir);
    }
  });

  // A press without turning is a button press on that part of the ring.
  p.wheel.addEventListener('pointerup', () => {
    if (drag && drag.travel < 8) pressWheel(drag.start);
    drag = null;
  });
  p.wheel.addEventListener('pointercancel', () => (drag = null));

  p.wheel.addEventListener(
    'wheel',
    (e) => {
      e.preventDefault();
      scrolled += e.deltaY;
      while (Math.abs(scrolled) >= 40) {
        const dir = Math.sign(scrolled);
        scrolled -= dir * 40;
        turnWheel(p, -dir);
      }
    },
    { passive: false },
  );

  p.wheel.addEventListener('keydown', (e) => {
    const action = {
      ArrowUp: () => turnWheel(p, 1),
      ArrowRight: () => turnWheel(p, 1),
      ArrowDown: () => turnWheel(p, -1),
      ArrowLeft: () => turnWheel(p, -1),
      ' ': togglePlay,
      Enter: () => toggleScrub(p),
    }[e.key];
    if (!action) return;
    e.preventDefault();
    action();
  });

  p.center.addEventListener('click', () => toggleScrub(p));
}

function pressWheel(angle) {
  // 0° is the right edge and angles grow clockwise, so the top of the ring is -90°.
  if (angle >= -135 && angle < -45) chrome.storage.local.set({ skin: 'modern' }); // MENU: back out
  else if (angle >= -45 && angle < 45) next();
  else if (angle >= 45 && angle < 135) togglePlay();
  else previous();
  wheelClick();
}

function turnWheel(p, dir) {
  const v = ui?.video;
  if (!v) return;
  wheelClick();
  if (p.root.classList.contains('mf-scrub')) {
    const end = Number.isFinite(v.duration) ? v.duration : v.currentTime;
    v.currentTime = Math.min(Math.max(v.currentTime + dir * SCRUB_STEP, 0), end);
    holdMode(p, 'mf-scrub');
  } else {
    v.muted = false;
    v.volume = Math.min(Math.max(Math.round((v.volume + dir * VOLUME_STEP) * 100) / 100, 0), 1);
    holdMode(p, 'mf-vol');
  }
}

function toggleScrub(p) {
  wheelClick();
  if (p.root.classList.contains('mf-scrub')) {
    clearTimeout(p.modeTimer);
    p.root.classList.remove('mf-scrub');
  } else {
    p.root.classList.remove('mf-vol');
    holdMode(p, 'mf-scrub');
  }
}

// Volume shows briefly; seeking stays on until the wheel rests for a few seconds.
function holdMode(p, mode) {
  p.root.classList.add(mode);
  clearTimeout(p.modeTimer);
  p.modeTimer = setTimeout(() => p.root.classList.remove('mf-vol', 'mf-scrub'), mode === 'mf-scrub' ? 5000 : 1500);
}

// The tiny tick the real click wheel makes.
function wheelClick() {
  try {
    wheelAudio ??= new AudioContext();
    const t = wheelAudio.currentTime;
    const osc = wheelAudio.createOscillator();
    const gain = wheelAudio.createGain();
    osc.type = 'square';
    osc.frequency.value = 2200;
    gain.gain.setValueAtTime(0.03, t);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.012);
    osc.connect(gain).connect(wheelAudio.destination);
    osc.start(t);
    osc.stop(t + 0.015);
  } catch {
    // Sound is a nicety; the wheel works without it.
  }
}

// ---------- Kept in sync by content.js ----------

function ipodSetTrack(p, title, artist) {
  p.title.textContent = title;
  p.artist.textContent = artist;
}

function ipodSyncTime(p, current, duration) {
  const finite = Number.isFinite(duration) && duration > 0;
  p.root.style.setProperty('--p', `${finite ? (current / duration) * 100 : 0}%`);
  p.elapsed.textContent = clock(current);
  p.remaining.textContent = duration === Infinity ? 'Live' : `-${clock(finite ? duration - current : 0)}`;
}

function ipodSyncVolume(p, level) {
  p.root.style.setProperty('--v', `${level * 100}%`);
}
